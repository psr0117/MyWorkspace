package com.demien.services;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.demien.cxfspringrest.utils.RestTestClient;
import com.demien.cxfspringrest.utils.RestTestServer;

public class TestServiceTest {
	private static RestTestServer server = new RestTestServer("JUNIT");
	private static RestTestClient client=new RestTestClient();
	
	@BeforeClass
	public static void init() throws Exception {
		server.start();
	}

	@AfterClass
	public static void finish() throws Exception {
		server.stop();
	}
	

	@Test
	public void test() throws Exception {
		System.out.println("Main test is started");
		String value=client.executeGetRequest("http://localhost:8080/spring-cxf-rest/services/rest/testService/sayhello");
		System.out.println("value="+value);
		assertEquals(value, "Hello world!");
		System.out.println("Main test is finished");
	}

}
