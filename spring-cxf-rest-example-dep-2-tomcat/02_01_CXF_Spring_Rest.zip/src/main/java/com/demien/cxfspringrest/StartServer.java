package com.demien.cxfspringrest;

import com.demien.cxfspringrest.utils.RestTestServer;

public class StartServer {

	public static void main(String[] args) throws Exception {
		new RestTestServer().start();

	}

}
